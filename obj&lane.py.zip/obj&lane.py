import cv2
import cvlib as cv
from cvlib.object_detection import draw_bbox
from vidgear.gears import CamGear

# Start the video stream
stream = CamGear(source='https://www.youtube.com/watch?v=TE2tfavIo3E', stream_mode=True, logging=True).start()

while True:
    # Read a frame from the video stream
    frame = stream.read()

    # Perform object detection
    bbox, label, conf = cv.detect_common_objects(frame)

    # Draw bounding boxes and labels on the frame
    output_frame = draw_bbox(frame, bbox, label, conf)

    # Display the frame with object detections
    cv2.imshow('Object Detection', output_frame)

    # Exit if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video stream and close all windows
stream.stop()
cv2.destroyAllWindows()
