import cv2
import cvlib as cv
from cvlib.object_detection import draw_bbox
from vidgear.gears import CamGear
import numpy as np

# Function to create a density map
def create_density_map(image, bboxes):
    height, width = image.shape[:2]
    density_map = np.zeros((height, width), dtype=np.float32)

    for bbox in bboxes:
        x1, y1, x2, y2 = bbox
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        density_map[y1:y2, x1:x2] += 1

    return density_map

stream = CamGear(source='https://www.youtube.com/watch?v=3kPH7kTphnE', stream_mode=True, logging=True).start()
count = 0

while True:
    frame = stream.read()


    frame = cv2.resize(frame, (1020, 600))
    bbox, label, conf = cv.detect_common_objects(frame)

    # Filter the results to include "person," "car," "bicycle," and "bike" labels
    filtered_labels = ["person", "car", "bicycle", "bike"]
    filtered_indices = [i for i, lbl in enumerate(label) if lbl in filtered_labels]
    filtered_bbox = [bbox[i] for i in filtered_indices]
    filtered_label = [label[i] for i in filtered_indices]
    filtered_conf = [conf[i] for i in filtered_indices]

    frame = draw_bbox(frame, filtered_bbox, filtered_label, filtered_conf)

    # Create a density map based on the detected objects
    density_map = create_density_map(frame, filtered_bbox)

    # Normalize the density map
    density_map = cv2.normalize(density_map, None, 0, 255, cv2.NORM_MINMAX)

    # Convert the density map to a color map for visualization
    density_map_color = cv2.applyColorMap(np.uint8(density_map), cv2.COLORMAP_JET)

    # Overlay the density map on top of the original frame
    result_frame = cv2.addWeighted(frame, 0.7, density_map_color, 0.3, 0)

    # Display the combined frame with density map and bounding boxes
    cv2.imshow("Frame with Density Map", result_frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

stream.stop()
cv2.destroyAllWindows()
